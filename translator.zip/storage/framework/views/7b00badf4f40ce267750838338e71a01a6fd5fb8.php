<?php $__env->startSection('title','Translator'); ?>

<?php $__env->startSection('content'); ?>
		<div>
			<?php if(auth()->guard()->check()): ?>
				<a class="menu_item_layer__first" href="<?php echo e(asset('logout')); ?>">LOG OUT</a>
				<a class="menu_item_layer__second" href="<?php echo e(asset('logout')); ?>">LOG OUT</a>
			<?php endif; ?>
			<?php if(auth()->guard()->guest()): ?>
				<a class="menu_item_layer__first" href="<?php echo e(asset('login')); ?>">LOG IN</a>
				<a class="menu_item_layer__second" href="<?php echo e(asset('login')); ?>">LOG IN</a>
			<?php endif; ?>
		</div>
	</div>
</header>
<script type="text/javascript" src="<?php echo e(asset('js/autocomplete.js')); ?>"></script>
<?php if(Session::has('syntax_error')): ?>
	<div id="modal" class="modal__body">
		<div class="modal__syntax_error">
			<div class="modal__close" onclick="modal_close()">X</div>
			<h2 class="modal__syntax_header">ERROR OCCURED!</h2>
			<div class="modal__syntax_body">Expression syntax, there is not sach command line as "<?php echo e(Session::get('syntax_error')); ?>"
				<div class="modal__syntax_error_fix">Fix commands and try again!</div>
			</div>
		</div>
	</div>
<?php elseif(Session::has('syntax')): ?>
	<div id="modal" class="modal__body">
		<div class="modal__syntax_code">
			<div class="modal__close" onclick="modal_close()">X</div>
			<h2 class="modal__syntax_header">TRANSLATED CODE</h2>
			<div class="modal__syntax_body">
				<?php $__currentLoopData = Session::get('syntax'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $syn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($syn); ?>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
<?php endif; ?>
<main>
	<form class="main__body" role="form" method="POST" action="<?php echo e(url('/translate')); ?>">
		<?php echo csrf_field(); ?>

	<article class="main__workspace">
		<div class="options">
			<h2>CODE EDITOR</h2>
			<span>Editor mode:</span>
			<div class="main__radio_btn">
				<input id="basic" type="radio" name="radio[]" value="basic" checked onchange="mode_select()">
				<label for="basic">Basic mode</label>
			</div>
			<div class="main__radio_btn">
				<input id="advanced" type="radio" name="radio[]" value="advanced" disabled onchange="mode_select()">
				<label for="advanced">Advanced mode</label>
			</div>
		</div>
		<textarea id="editor" class="main__editor" name="editor" ><?php echo e(old('editor')); ?></textarea>
	</article>
	<aside class="main__options">
		<div class="options">
			<h2>OPTIONS</h2>
			<span>Programming language:</span>
			<div class="main__radio_btn">
				<input id="C" type="radio" name="radio_l" value="1" checked>
				<label for="C">C</label>
			</div>
			<div class="main__radio_btn">
				<input id="Cpp" type="radio" name="radio_l" value="2">
				<label for="Cpp">C++</label>
			</div>
			<div class="main__radio_btn">
				<input id="CS" type="radio" name="radio_l" value="3">
				<label for="CS">C#</label>
			</div>
			<div class="main__radio_btn">
				<input id="php" type="radio" name="radio_l" value="4">
				<label for="php">PHP</label>
			</div>
		</div>
		<div id="helper" class="main__option_help" unselectable="on"></div>
		<input class="main__submit" type="submit" name="s" value="PROCESS">
	</aside>
	</form>
</main>
<footer>
	
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Halkon\Downloads\OSPanel\domains\translator\resources\views/working.blade.php ENDPATH**/ ?>