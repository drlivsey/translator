<?php $__env->startSection('title','Registration'); ?>

<?php $__env->startSection('content'); ?>
		<div>
			<a class="menu_item_layer__first" href="<?php echo e(asset('login')); ?>">LOG IN</a>
			<a class="menu_item_layer__second" href="<?php echo e(asset('login')); ?>">LOG IN</a>
		</div>
	</div>
</header>
<main>
	<form class="reg_form" role="form" method="post" action="<?php echo e(url('/reg')); ?>"> 
		<?php echo csrf_field(); ?>

		<h1 class="reg_form__title">REGISTRATION</h1>
		<div>
			<input type="text" id="login" name="login" required>
			<label class="reg_form__movable_label" for="login">Email</label>
			<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<div>
			<input type="text" id="password" name="password" required>
			<label class="reg_form__movable_label" for="password">Password</label>
			<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<div>
			<input type="submit" name="s" value="GO">
		</div>
	</form>
</main>
<footer>
	
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Halkon\Downloads\OSPanel\domains\translator\resources\views/registration.blade.php ENDPATH**/ ?>