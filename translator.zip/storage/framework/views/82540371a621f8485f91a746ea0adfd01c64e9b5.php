<?php $__env->startSection('title','News'); ?>

<?php $__env->startSection('content'); ?>
		<div>
			<?php if(auth()->guard()->check()): ?>
				<a class="menu_item_layer__first" href="<?php echo e(asset('logout')); ?>">LOG OUT</a>
				<a class="menu_item_layer__second" href="<?php echo e(asset('logout')); ?>">LOG OUT</a>
			<?php endif; ?>
			<?php if(auth()->guard()->guest()): ?>
				<a class="menu_item_layer__first" href="<?php echo e(asset('login')); ?>">LOG IN</a>
				<a class="menu_item_layer__second" href="<?php echo e(asset('login')); ?>">LOG IN</a>
			<?php endif; ?>
		</div>
	</div>
</header>
<main class="news__body">
	<section  class="news__main">
	<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php 
			$date_time = explode(' ', $article->updated_at);
		?>
		<article class="news__one">
			<h2 class="news__header"><?php echo e($article->header); ?></h2>
			<div class="news__info">Published by <?php echo e($article->author); ?> | <?php echo e(Carbon\Carbon::parse($date_time[0])->format('d.m.Y')); ?> | <?php echo e($date_time[1]); ?></div>
			<p class="news__paragraph"><?php echo e($article->article); ?></p>
		</article>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</section>
	<aside class="news__aside">
		<h2 class="news__aside_header">NOW AVAILABLE LANGUAGES</h2>
		<div class="news__aside_languages">
			<div class="news__aside_lang">C</div>
			<div class="news__aside_lang">C++</div>
			<div class="news__aside_lang">C#</div>
			<div class="news__aside_lang">PHP</div>
		</div>
	</aside>
</main>
<footer>
	
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Halkon\Downloads\OSPanel\domains\translator\resources\views/home.blade.php ENDPATH**/ ?>