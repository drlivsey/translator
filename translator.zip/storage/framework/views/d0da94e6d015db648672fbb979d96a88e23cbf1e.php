<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
<header>
	<img src="<?php echo e(asset('images/logo.png')); ?>">
	<div class="menu">
		<div>
			<?php if(auth()->guard()->check()): ?>
				<a class="menu_item_layer__first" href="<?php echo e(asset('translate')); ?>">TRANSLATE</a>
				<a class="menu_item_layer__second" href="<?php echo e(asset('translate')); ?>">TRANSLATE</a>
			<?php endif; ?>
			<?php if(auth()->guard()->guest()): ?>
				<a class="menu_item_layer__first" href="<?php echo e(asset('translate')); ?>">START WORK</a>
				<a class="menu_item_layer__second" href="<?php echo e(asset('translate')); ?>">START WORK</a>
			<?php endif; ?>
		</div>
		<div>
			<a class="menu_item_layer__first" href="<?php echo e(asset('home')); ?>">NEWS</a>
			<a class="menu_item_layer__second" href="<?php echo e(asset('home')); ?>">NEWS</a>
		</div>
		<div>
			<a class="menu_item_layer__first" href="<?php echo e(asset('rules')); ?>">RULES</a>
			<a class="menu_item_layer__second" href="<?php echo e(asset('rules')); ?>">RULES</a>
		</div>
		<div>
			<a class="menu_item_layer__first" href="<?php echo e(asset('help')); ?>">HELP</a>
			<a class="menu_item_layer__second" href="<?php echo e(asset('help')); ?>">HELP</a>
		</div>
		<div>
			<a class="menu_item_layer__first" href="<?php echo e(asset('about')); ?>">ABOUT US</a>
			<a class="menu_item_layer__second" href="<?php echo e(asset('about')); ?>">ABOUT US</a>
		</div>
	<?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\Users\Halkon\Downloads\OSPanel\domains\translator\resources\views/layout.blade.php ENDPATH**/ ?>